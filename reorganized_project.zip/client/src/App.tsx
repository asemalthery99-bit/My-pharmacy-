import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import MedicineCatalog from "./pages/MedicineCatalog";
import MedicineDetail from "./pages/MedicineDetail";
import Cart from "./pages/Cart";
import Orders from "./pages/Orders";
import PharmacistDashboard from "./pages/PharmacistDashboard";
import PrescriptionUpload from "./pages/PrescriptionUpload";
import AIChatbot from "./pages/AIChatbot";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/catalog" component={MedicineCatalog} />
      <Route path="/medicine/:id" component={MedicineDetail} />
      <Route path="/cart" component={Cart} />
      <Route path="/orders" component={Orders} />
      <Route path="/pharmacist" component={PharmacistDashboard} />
      <Route path="/prescription" component={PrescriptionUpload} />
      <Route path="/chatbot" component={AIChatbot} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
