import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Pill, ArrowLeft, Clock, CheckCircle, Package } from "lucide-react";
import { Link } from "wouter";

const statusConfig: any = {
  pending: { label: "قيد المراجعة", icon: Clock, color: "text-yellow-600", bg: "bg-yellow-50" },
  approved: { label: "تم الموافقة", icon: CheckCircle, color: "text-blue-600", bg: "bg-blue-50" },
  ready: { label: "جاهز للاستلام", icon: Package, color: "text-green-600", bg: "bg-green-50" },
  completed: { label: "مكتمل", icon: CheckCircle, color: "text-emerald-600", bg: "bg-emerald-50" },
  cancelled: { label: "ملغى", icon: Clock, color: "text-red-600", bg: "bg-red-50" },
};

export default function Orders() {
  const { isAuthenticated } = useAuth();
  const { data: orders } = trpc.orders.list.useQuery(undefined, { enabled: isAuthenticated });

  if (!isAuthenticated) {
    return <div className="p-8 text-center">يجب تسجيل الدخول أولاً</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <nav className="sticky top-0 z-50 bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/"><a className="flex items-center gap-2"><Pill className="w-8 h-8 text-emerald-600" /><span className="text-2xl font-bold">IBPharmacy</span></a></Link>
          <Link href="/"><a className="text-emerald-600 hover:text-emerald-700 flex items-center gap-2"><ArrowLeft className="w-4 h-4" />الرئيسية</a></Link>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold mb-8 text-slate-900">الطلبات</h1>

        {!orders || orders.length === 0 ? (
          <Card className="border-slate-200">
            <CardContent className="p-8 text-center">
              <p className="text-xl text-slate-600">لا توجد طلبات بعد</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {orders.map((order: any) => {
              const config = statusConfig[order.status];
              const Icon = config?.icon || Clock;
              return (
                <Card key={order.id} className={`border-slate-200 ${config?.bg}`}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>الطلب #{order.id}</CardTitle>
                        <p className="text-sm text-slate-600 mt-1">
                          {new Date(order.createdAt).toLocaleDateString('ar-SA')}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Icon className={`w-6 h-6 ${config?.color}`} />
                        <span className={`font-bold ${config?.color}`}>{config?.label}</span>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm text-slate-600">المجموع</p>
                        <p className="text-2xl font-bold text-emerald-600">{order.totalPrice} ر.س</p>
                      </div>
                      <Link href={`/orders/${order.id}`}>
                        <a className="text-emerald-600 hover:text-emerald-700 font-medium">عرض التفاصيل</a>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
