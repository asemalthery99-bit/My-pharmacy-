import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Pill, ArrowLeft, ShoppingCart } from "lucide-react";
import { Link, useRoute } from "wouter";
import { useState } from "react";

export default function MedicineDetail() {
  const [, params] = useRoute("/medicine/:id");
  const { isAuthenticated } = useAuth();
  const [quantity, setQuantity] = useState(1);
  const medicineId = parseInt(params?.id || "0");
  const { data: medicine } = trpc.medicines.detail.useQuery({ id: medicineId });
  const addToCart = trpc.cart.add.useMutation();

  const handleAddToCart = async () => {
    if (!isAuthenticated) {
      alert("يجب تسجيل الدخول أولاً");
      return;
    }
    await addToCart.mutateAsync({ medicineId, quantity });
    alert("تم إضافة الدواء إلى السلة");
    window.location.href = "/cart";
  };

  if (!medicine) return <div className="p-8 text-center">جاري التحميل...</div>;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <nav className="sticky top-0 z-50 bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/"><a className="flex items-center gap-2"><Pill className="w-8 h-8 text-emerald-600" /><span className="text-2xl font-bold">IBPharmacy</span></a></Link>
          <Link href="/catalog"><a className="text-emerald-600 hover:text-emerald-700 flex items-center gap-2"><ArrowLeft className="w-4 h-4" />العودة</a></Link>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-emerald-100 rounded-2xl p-8 flex items-center justify-center h-96">
            <Pill className="w-40 h-40 text-emerald-600" />
          </div>

          <div>
            <h1 className="text-4xl font-bold mb-2 text-slate-900">{medicine.arabicName}</h1>
            <p className="text-lg text-slate-600 mb-6">{medicine.name}</p>

            <Card className="mb-6 border-slate-200">
              <CardHeader>
                <CardTitle>معلومات الدواء</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-slate-600">المادة الفعالة</p>
                  <p className="font-semibold">{medicine.activeIngredient}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600">الشركة المصنعة</p>
                  <p className="font-semibold">{medicine.manufacturer}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600">السعر</p>
                  <p className="text-3xl font-bold text-emerald-600">{medicine.price} ر.س</p>
                </div>
              </CardContent>
            </Card>

            <div className="flex gap-4 items-center mb-6">
              <div className="flex items-center gap-2">
                <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="px-3 py-2 border rounded">-</button>
                <span className="px-4 py-2">{quantity}</span>
                <button onClick={() => setQuantity(quantity + 1)} className="px-3 py-2 border rounded">+</button>
              </div>
              <Button
                onClick={handleAddToCart}
                disabled={medicine.quantity === 0}
                className="flex-1 bg-emerald-600 hover:bg-emerald-700"
              >
                <ShoppingCart className="ml-2 w-4 h-4" />
                {medicine.quantity > 0 ? 'أضف إلى السلة' : 'غير متوفر'}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
