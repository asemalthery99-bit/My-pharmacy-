import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Pill, Upload, ArrowLeft, Loader2 } from "lucide-react";
import { Link } from "wouter";
import { useState, useRef } from "react";

export default function PrescriptionUpload() {
  const { isAuthenticated } = useAuth();
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [extractedMedicines, setExtractedMedicines] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const uploadPrescription = trpc.prescriptions.upload.useMutation();
  const extractMedicines = trpc.prescriptions.extractMedicines.useMutation();

  if (!isAuthenticated) {
    return <div className="p-8 text-center">يجب تسجيل الدخول أولاً</div>;
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      const reader = new FileReader();
      reader.onload = (event) => {
        setPreview(event.target?.result as string);
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const handleExtractMedicines = async () => {
    if (!file) {
      alert("يرجى اختيار صورة الوصفة أولاً");
      return;
    }

    setLoading(true);
    try {
      const result = await extractMedicines.mutateAsync({ 
        imageUrl: preview 
      });
      
      setExtractedMedicines(result.medicines || []);
    } catch (error) {
      alert("فشل في استخراج الأدوية من الوصفة");
    } finally {
      setLoading(false);
    }
  };

  const handleUploadPrescription = async () => {
    if (!file || extractedMedicines.length === 0) {
      alert("يرجى استخراج الأدوية أولاً");
      return;
    }

    try {
      await uploadPrescription.mutateAsync({
        imageUrl: preview,
        medicines: extractedMedicines
      });
      alert("تم رفع الوصفة بنجاح");
      setFile(null);
      setPreview("");
      setExtractedMedicines([]);
    } catch (error) {
      alert("فشل في رفع الوصفة");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <nav className="sticky top-0 z-50 bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/"><a className="flex items-center gap-2"><Pill className="w-8 h-8 text-emerald-600" /><span className="text-2xl font-bold">IBPharmacy</span></a></Link>
          <Link href="/"><a className="text-emerald-600 hover:text-emerald-700 flex items-center gap-2"><ArrowLeft className="w-4 h-4" />الرئيسية</a></Link>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold mb-8 text-slate-900">رفع الوصفة الطبية</h1>

        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <Card className="border-slate-200">
              <CardHeader>
                <CardTitle>اختر صورة الوصفة</CardTitle>
              </CardHeader>
              <CardContent>
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-emerald-300 rounded-lg p-8 text-center cursor-pointer hover:bg-emerald-50 transition-colors"
                >
                  {preview ? (
                    <img src={preview} alt="الوصفة" className="max-h-64 mx-auto rounded" />
                  ) : (
                    <div>
                      <Upload className="w-16 h-16 mx-auto text-emerald-600 mb-4" />
                      <p className="text-lg font-semibold mb-2">انقر لاختيار صورة الوصفة</p>
                      <p className="text-sm text-slate-600">أو اسحب وأفلت الصورة هنا</p>
                    </div>
                  )}
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileSelect}
                  className="hidden"
                />
                
                {file && (
                  <div className="mt-6 space-y-3">
                    <Button
                      onClick={handleExtractMedicines}
                      disabled={loading}
                      className="w-full bg-emerald-600 hover:bg-emerald-700"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="ml-2 w-4 h-4 animate-spin" />
                          جاري المعالجة...
                        </>
                      ) : (
                        "استخراج الأدوية من الوصفة"
                      )}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div>
            {extractedMedicines.length > 0 && (
              <Card className="border-slate-200">
                <CardHeader>
                  <CardTitle>الأدوية المستخرجة</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    {extractedMedicines.map((medicine, index) => (
                      <div key={index} className="p-3 bg-emerald-50 rounded border border-emerald-200">
                        <p className="font-semibold text-emerald-700">{medicine}</p>
                      </div>
                    ))}
                  </div>
                  
                  <Button
                    onClick={handleUploadPrescription}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                  >
                    تأكيد ورفع الوصفة
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
