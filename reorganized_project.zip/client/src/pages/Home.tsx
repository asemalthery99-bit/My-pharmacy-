import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Pill, Heart, Truck, Shield, Search, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useState } from "react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const { data: medicines } = trpc.medicines.list.useQuery({ search: searchQuery, limit: 6 });
  const { data: categories } = trpc.medicines.categories.useQuery();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Pill className="w-8 h-8 text-emerald-600" />
            <span className="text-2xl font-bold text-slate-900">IBPharmacy Pro</span>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/catalog">
              <a className="text-slate-600 hover:text-slate-900 font-medium">الكتالوج</a>
            </Link>
            {isAuthenticated ? (
              <>
                <Link href="/cart">
                  <a className="text-slate-600 hover:text-slate-900 font-medium">السلة</a>
                </Link>
                <Link href="/orders">
                  <a className="text-slate-600 hover:text-slate-900 font-medium">الطلبات</a>
                </Link>
                <span className="text-sm text-slate-600">{user?.name}</span>
              </>
            ) : (
              <a href={getLoginUrl()} className="text-slate-600 hover:text-slate-900 font-medium">
                تسجيل الدخول
              </a>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-r from-emerald-600 to-emerald-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl font-bold mb-6">صيدليتك الموثوقة</h1>
              <p className="text-xl text-emerald-50 mb-8">
                احصل على أفضل الأدوية والعلاجات بأسعار منافسة مع توصيل سريع وآمن
              </p>
              <div className="flex gap-4">
                <Link href="/catalog">
                  <Button size="lg" className="bg-white text-emerald-600 hover:bg-emerald-50">
                    تصفح الأدوية <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </div>
            <div className="hidden md:block">
              <div className="bg-emerald-500 rounded-2xl p-8 text-center">
                <Pill className="w-32 h-32 mx-auto text-emerald-100" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12 text-slate-900">لماذا تختار IBPharmacy؟</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { icon: Truck, title: "توصيل سريع", desc: "توصيل في نفس اليوم" },
              { icon: Shield, title: "آمن وموثوق", desc: "أدوية أصلية معتمدة" },
              { icon: Heart, title: "رعاية صحية", desc: "استشارات صيدلانية مجانية" },
              { icon: Pill, title: "تنوع كبير", desc: "آلاف الأدوية المتاحة" },
            ].map((feature, i) => {
              const Icon = feature.icon;
              return (
                <Card key={i} className="border-slate-200 hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <Icon className="w-8 h-8 text-emerald-600 mb-2" />
                    <CardTitle className="text-lg">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-600">{feature.desc}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Search Section */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-8 text-slate-900">ابحث عن دواء</h2>
          <div className="max-w-2xl mx-auto relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
            <Input
              type="text"
              placeholder="ابحث عن اسم الدواء..."
              className="pl-12 py-6 text-lg border-2 border-slate-200 rounded-xl"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </section>

      {/* Featured Medicines */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <h2 className="text-3xl font-bold text-slate-900">الأدوية المشهورة</h2>
            <Link href="/catalog">
              <a className="text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-2">
                عرض الكل <ArrowRight className="w-4 h-4" />
              </a>
            </Link>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {medicines?.slice(0, 6).map((medicine: any) => (
              <Link key={medicine.id} href={`/medicine/${medicine.id}`}>
                <a className="group">
                  <Card className="border-slate-200 hover:shadow-xl transition-all duration-300 h-full">
                    <CardHeader>
                      <div className="bg-emerald-100 rounded-lg p-4 mb-4 h-32 flex items-center justify-center group-hover:bg-emerald-200 transition-colors">
                        <Pill className="w-16 h-16 text-emerald-600" />
                      </div>
                      <CardTitle className="line-clamp-2">{medicine.arabicName}</CardTitle>
                      <CardDescription className="text-xs">{medicine.activeIngredient}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-bold text-emerald-600">
                          {medicine.price} ر.س
                        </span>
                        {medicine.quantity > 0 ? (
                          <span className="text-xs bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full">
                            متوفر
                          </span>
                        ) : (
                          <span className="text-xs bg-red-100 text-red-700 px-3 py-1 rounded-full">
                            غير متوفر
                          </span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </a>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-emerald-600 to-emerald-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">هل أنت صيدلاني؟</h2>
          <p className="text-xl text-emerald-50 mb-8">انضم إلى فريقنا وأدر صيدليتك بكفاءة</p>
          <Button size="lg" className="bg-white text-emerald-600 hover:bg-emerald-50">
            تسجيل الدخول كصيدلاني
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-300 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-white mb-4">IBPharmacy Pro</h3>
              <p className="text-sm">منصة صيدلية موثوقة لتوفير الأدوية والعلاجات</p>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">الروابط</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/catalog"><a className="hover:text-white">الكتالوج</a></Link></li>
                <li><Link href="/about"><a className="hover:text-white">عن الموقع</a></Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">الدعم</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white">الأسئلة الشائعة</a></li>
                <li><a href="#" className="hover:text-white">اتصل بنا</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">القانوني</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white">سياسة الخصوصية</a></li>
                <li><a href="#" className="hover:text-white">الشروط والأحكام</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-800 pt-8 text-center text-sm">
            <p>&copy; 2026 IBPharmacy Pro. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
