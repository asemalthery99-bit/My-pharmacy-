import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Pill, ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default function MedicineCatalog() {
  const [search, setSearch] = useState("");
  const [categoryId, setCategoryId] = useState<number | undefined>();
  const { data: medicines } = trpc.medicines.list.useQuery({ search, categoryId });
  const { data: categories } = trpc.medicines.categories.useQuery();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <nav className="sticky top-0 z-50 bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/"><a className="flex items-center gap-2"><Pill className="w-8 h-8 text-emerald-600" /><span className="text-2xl font-bold">IBPharmacy</span></a></Link>
          <Link href="/"><a className="text-emerald-600 hover:text-emerald-700">العودة للرئيسية</a></Link>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold mb-8 text-slate-900">كتالوج الأدوية</h1>

        <div className="grid lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="font-bold text-lg mb-4">البحث والفلترة</h3>
              <Input
                type="text"
                placeholder="ابحث عن دواء..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="mb-6"
              />
              <div>
                <h4 className="font-semibold mb-3">الفئات</h4>
                <button
                  onClick={() => setCategoryId(undefined)}
                  className={`block w-full text-left px-3 py-2 rounded mb-2 ${!categoryId ? 'bg-emerald-100 text-emerald-700' : 'hover:bg-slate-100'}`}
                >
                  جميع الفئات
                </button>
                {categories?.map((cat: any) => (
                  <button
                    key={cat.id}
                    onClick={() => setCategoryId(cat.id)}
                    className={`block w-full text-left px-3 py-2 rounded mb-2 ${categoryId === cat.id ? 'bg-emerald-100 text-emerald-700' : 'hover:bg-slate-100'}`}
                  >
                    {cat.name}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-3">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {medicines?.map((medicine: any) => (
                <Link key={medicine.id} href={`/medicine/${medicine.id}`}>
                  <a className="group">
                    <Card className="border-slate-200 hover:shadow-xl transition-all h-full">
                      <CardHeader>
                        <div className="bg-emerald-100 rounded-lg p-4 mb-4 h-32 flex items-center justify-center group-hover:bg-emerald-200 transition-colors">
                          <Pill className="w-16 h-16 text-emerald-600" />
                        </div>
                        <CardTitle className="line-clamp-2">{medicine.arabicName}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-slate-600 mb-3">{medicine.activeIngredient}</p>
                        <div className="flex items-center justify-between">
                          <span className="text-2xl font-bold text-emerald-600">{medicine.price}</span>
                          <span className={`text-xs px-2 py-1 rounded ${medicine.quantity > 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                            {medicine.quantity > 0 ? 'متوفر' : 'غير متوفر'}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  </a>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
