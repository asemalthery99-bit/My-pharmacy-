import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Pill, Trash2, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function Cart() {
  const { isAuthenticated } = useAuth();
  const { data: cartItems, refetch } = trpc.cart.list.useQuery(undefined, { enabled: isAuthenticated });
  const removeFromCart = trpc.cart.remove.useMutation();
  const createOrder = trpc.orders.create.useMutation();

  if (!isAuthenticated) {
    return <div className="p-8 text-center">يجب تسجيل الدخول أولاً</div>;
  }

  const total = cartItems?.reduce((sum: number, item: any) => sum + (parseFloat(item.medicine?.price || 0) * item.quantity), 0) || 0;

  const handleCheckout = async () => {
    if (!cartItems || cartItems.length === 0) {
      alert("السلة فارغة");
      return;
    }
    const items = cartItems.map((item: any) => ({ medicineId: item.medicineId, quantity: item.quantity }));
    await createOrder.mutateAsync({ items });
    alert("تم إنشاء الطلب بنجاح");
    window.location.href = "/orders";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <nav className="sticky top-0 z-50 bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/"><a className="flex items-center gap-2"><Pill className="w-8 h-8 text-emerald-600" /><span className="text-2xl font-bold">IBPharmacy</span></a></Link>
          <Link href="/"><a className="text-emerald-600 hover:text-emerald-700 flex items-center gap-2"><ArrowLeft className="w-4 h-4" />الرئيسية</a></Link>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold mb-8 text-slate-900">سلة التسوق</h1>

        {!cartItems || cartItems.length === 0 ? (
          <Card className="border-slate-200">
            <CardContent className="p-8 text-center">
              <p className="text-xl text-slate-600 mb-4">السلة فارغة</p>
              <Link href="/catalog"><Button className="bg-emerald-600">تصفح الأدوية</Button></Link>
            </CardContent>
          </Card>
        ) : (
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-4">
              {cartItems.map((item: any) => (
                <Card key={item.id} className="border-slate-200">
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex-1">
                      <h3 className="font-bold text-lg">{item.medicine?.arabicName}</h3>
                      <p className="text-sm text-slate-600">{item.medicine?.activeIngredient}</p>
                      <p className="text-emerald-600 font-bold mt-2">الكمية: {item.quantity}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-emerald-600">{parseFloat(item.medicine?.price || 0) * item.quantity}</p>
                      <button onClick={async () => { await removeFromCart.mutateAsync({ cartItemId: item.id }); refetch(); }} className="text-red-600 hover:text-red-700 mt-2">
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div>
              <Card className="border-slate-200 sticky top-24">
                <CardHeader>
                  <CardTitle>ملخص الطلب</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span>المجموع</span>
                    <span className="font-bold text-2xl text-emerald-600">{total.toFixed(2)} ر.س</span>
                  </div>
                  <Button onClick={handleCheckout} className="w-full bg-emerald-600 hover:bg-emerald-700">
                    إتمام الطلب
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
