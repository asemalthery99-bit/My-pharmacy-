import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Pill, LogOut, Package, CheckCircle, Clock } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";

export default function PharmacistDashboard() {
  const { user, isAuthenticated, logout } = useAuth();
  const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);
  
  const { data: orders } = trpc.orders.listForPharmacist.useQuery(undefined, { enabled: isAuthenticated && user?.role === 'admin' });
  const { data: selectedOrder } = trpc.orders.detail.useQuery({ id: selectedOrderId || 0 }, { enabled: !!selectedOrderId });
  const updateOrderStatus = trpc.orders.updateStatus.useMutation();

  if (!isAuthenticated || user?.role !== 'admin') {
    return <div className="p-8 text-center text-red-600">لا توجد صلاحيات للوصول إلى هذه الصفحة</div>;
  }

  const handleStatusUpdate = async (orderId: number, newStatus: 'pending' | 'approved' | 'ready' | 'completed' | 'cancelled') => {
    await updateOrderStatus.mutateAsync({ orderId, status: newStatus });
    alert("تم تحديث حالة الطلب");
  };

  const statusConfig: any = {
    pending: { label: "قيد المراجعة", color: "bg-yellow-100 text-yellow-700" },
    approved: { label: "تم الموافقة", color: "bg-blue-100 text-blue-700" },
    ready: { label: "جاهز للاستلام", color: "bg-green-100 text-green-700" },
    completed: { label: "مكتمل", color: "bg-emerald-100 text-emerald-700" },
    cancelled: { label: "ملغى", color: "bg-red-100 text-red-700" },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <nav className="sticky top-0 z-50 bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/"><a className="flex items-center gap-2"><Pill className="w-8 h-8 text-emerald-600" /><span className="text-2xl font-bold">IBPharmacy</span></a></Link>
          <div className="flex items-center gap-4">
            <span className="text-slate-600">مرحباً، {user?.name}</span>
            <Button onClick={logout} variant="outline" className="flex items-center gap-2">
              <LogOut className="w-4 h-4" />
              تسجيل الخروج
            </Button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold mb-8 text-slate-900">لوحة تحكم الصيدلاني</h1>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card className="border-slate-200">
              <CardHeader>
                <CardTitle>الطلبات المعلقة</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {orders?.map((order: any) => (
                    <div
                      key={order.id}
                      onClick={() => setSelectedOrderId(order.id)}
                      className={`p-4 border rounded-lg cursor-pointer transition-all ${
                        selectedOrderId === order.id ? 'border-emerald-600 bg-emerald-50' : 'border-slate-200 hover:border-emerald-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-bold">الطلب #{order.id}</p>
                          <p className="text-sm text-slate-600">المريض: {order.user?.name}</p>
                          <p className="text-sm text-slate-600">المجموع: {order.totalPrice} ر.س</p>
                        </div>
                        <div className={`px-3 py-1 rounded text-sm font-semibold ${statusConfig[order.status]?.color}`}>
                          {statusConfig[order.status]?.label}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            {selectedOrder && (
              <Card className="border-slate-200 sticky top-24">
                <CardHeader>
                  <CardTitle>تفاصيل الطلب</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm text-slate-600">رقم الطلب</p>
                    <p className="font-bold">{selectedOrder.id}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">المريض</p>
                    <p className="font-bold">مريض</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">الأدوية</p>
                    <div className="space-y-2">
                      {selectedOrder.items?.map((item: any) => (
                        <div key={item.id} className="text-sm">
                          <p className="font-semibold">{item.medicine?.arabicName}</p>
                          <p className="text-slate-600">الكمية: {item.quantity}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Button
                      onClick={() => handleStatusUpdate(selectedOrder.id, 'approved')}
                      className="w-full bg-blue-600 hover:bg-blue-700"
                    >
                      الموافقة على الطلب
                    </Button>
                    <Button
                      onClick={() => handleStatusUpdate(selectedOrder.id, 'ready')}
                      className="w-full bg-green-600 hover:bg-green-700"
                    >
                      تحديد كجاهز
                    </Button>
                    <Button
                      onClick={() => handleStatusUpdate(selectedOrder.id, 'completed')}
                      className="w-full bg-emerald-600 hover:bg-emerald-700"
                    >
                      تحديد كمكتمل
                    </Button>
                    <Button
                      onClick={() => handleStatusUpdate(selectedOrder.id, 'cancelled')}
                      className="w-full bg-red-600 hover:bg-red-700"
                    >
                      إلغاء الطلب
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
