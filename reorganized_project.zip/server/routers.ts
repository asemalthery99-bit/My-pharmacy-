import { COOKIE_NAME } from "../shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { eq } from "drizzle-orm";
import * as db from "./db";
import { getDb } from "./db";
import { medicines, cartItems, orders, orderItems as orderItemsTable, prescriptions, InsertOrder, InsertOrderItem, InsertPrescription } from "../drizzle/schema";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  medicines: router({
    list: publicProcedure
      .input(z.object({
        categoryId: z.number().optional(),
        search: z.string().optional(),
        limit: z.number().default(20),
      }))
      .query(async ({ input }) => {
        return db.getMedicines({
          categoryId: input.categoryId,
          search: input.search,
        });
      }),

    detail: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getMedicineById(input.id);
      }),

    categories: publicProcedure
      .query(async () => {
        return db.getCategories();
      }),
  }),

  cart: router({
    list: protectedProcedure
      .query(async ({ ctx }) => {
        const items = await db.getCartItems(ctx.user.id);
        const itemsWithMedicines = await Promise.all(
          items.map(async (item) => ({
            ...item,
            medicine: await db.getMedicineById(item.medicineId),
          }))
        );
        return itemsWithMedicines;
      }),

    add: protectedProcedure
      .input(z.object({
        medicineId: z.number(),
        quantity: z.number().min(1),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.addToCart(ctx.user.id, input.medicineId, input.quantity);
        return { success: true };
      }),

    remove: protectedProcedure
      .input(z.object({ cartItemId: z.number() }))
      .mutation(async ({ input }) => {
        await db.removeFromCart(input.cartItemId);
        return { success: true };
      }),
  }),

  orders: router({
    list: protectedProcedure
      .query(async ({ ctx }) => {
        return db.getUserOrders(ctx.user.id);
      }),

    detail: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const order = await db.getOrderById(input.id);
        if (!order || order.userId !== ctx.user.id) {
          throw new Error("Order not found");
        }
        const items = await db.getOrderItems(input.id);
        const itemsWithMedicines = await Promise.all(
          items.map(async (item) => ({
            ...item,
            medicine: await db.getMedicineById(item.medicineId),
          }))
        );
        return { ...order, items: itemsWithMedicines };
      }),

    create: protectedProcedure
      .input(z.object({
        items: z.array(z.object({
          medicineId: z.number(),
          quantity: z.number().min(1),
        })),
      }))
      .mutation(async ({ ctx, input }) => {
        const dbInstance = await getDb();
        if (!dbInstance) throw new Error("Database not available");

        let totalPrice = 0;
        const medicinesData = await Promise.all(
          input.items.map(async (item) => {
            const medicine = await db.getMedicineById(item.medicineId);
            if (!medicine) throw new Error(`Medicine ${item.medicineId} not found`);
            totalPrice += parseFloat(medicine.price.toString()) * item.quantity;
            return { ...item, price: medicine.price };
          })
        );

        const orderData: InsertOrder = {
          userId: ctx.user.id,
          totalPrice: totalPrice.toString() as any,
          status: "pending",
        };

        const result = await dbInstance.insert(orders).values(orderData);
        const orderId = (result as any).insertId;

        for (const item of medicinesData) {
          const orderItemData: InsertOrderItem = {
            orderId,
            medicineId: item.medicineId,
            quantity: item.quantity,
            price: item.price.toString() as any,
          };
          await dbInstance.insert(orderItemsTable).values(orderItemData);
        }

        const cartItemsToDelete = await db.getCartItems(ctx.user.id);
        for (const cartItem of cartItemsToDelete) {
          await db.removeFromCart(cartItem.id);
        }

        return { orderId, success: true };
      }),

    listForPharmacist: protectedProcedure
      .query(async ({ ctx }) => {
        if (ctx.user.role !== "admin") {
          throw new Error("Unauthorized");
        }
        const dbInstance = await getDb();
        if (!dbInstance) return [];
        return dbInstance.select().from(orders);
      }),

    updateStatus: protectedProcedure
      .input(z.object({
        orderId: z.number(),
        status: z.enum(["pending", "approved", "ready", "completed", "cancelled"]),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new Error("Unauthorized");
        }
        const dbInstance = await getDb();
        if (!dbInstance) throw new Error("Database not available");

        await dbInstance.update(orders).set({ status: input.status }).where(eq(orders.id, input.orderId));
        return { success: true };
      }),
  }),

  prescriptions: router({
    list: protectedProcedure
      .query(async ({ ctx }) => {
        return db.getUserPrescriptions(ctx.user.id);
      }),

    upload: protectedProcedure
      .input(z.object({
        imageUrl: z.string(),
        medicines: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const prescriptionData: InsertPrescription = {
          userId: ctx.user.id,
          imageUrl: input.imageUrl,
          status: "pending",
        };

        const dbInstance = await getDb();
        if (!dbInstance) throw new Error("Database not available");

        const result = await dbInstance.insert(prescriptions).values(prescriptionData);
        return { prescriptionId: (result as any).insertId, success: true };
      }),

    extractMedicines: protectedProcedure
      .input(z.object({
        imageUrl: z.string(),
      }))
      .mutation(async () => {
        return {
          medicines: [
            "باراسيتامول 500 ملغ",
            "أموكسيسيلين 250 ملغ",
            "إيبوبروفين 200 ملغ"
          ]
        };
      }),
  }),

  chatbot: router({
    ask: protectedProcedure
      .input(z.object({
        question: z.string(),
      }))
      .mutation(async ({ input }) => {
        const responses: any = {
          "باراسيتامول": "الباراسيتامول هو مسكن للألم وخافض للحرارة. الجرعة الموصى بها هي 500-1000 ملغ كل 4-6 ساعات.",
          "أموكسيسيلين": "الأموكسيسيلين هو مضاد حيوي من فئة البنسلين. يستخدم لعلاج العدوى البكتيرية.",
          "إيبوبروفين": "الإيبوبروفين هو مسكن ومضاد التهاب. الجرعة الموصى بها هي 200-400 ملغ كل 4-6 ساعات.",
        };

        let answer = "عذراً، لا أملك معلومات حول هذا السؤال. يرجى استشارة الصيدلاني.";
        for (const [key, value] of Object.entries(responses)) {
          if (input.question.includes(key)) {
            answer = value as string;
            break;
          }
        }

        return { answer };
      }),
  }),
});

export type AppRouter = typeof appRouter;
