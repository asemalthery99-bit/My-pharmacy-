# IBPharmacy Pro - منصة صيدلية إلكترونية متكاملة

منصة صيدلية حديثة وآمنة توفر تجربة تسوق سلسة للأدوية والعلاجات مع نظام إدارة متقدم للصيدلانيين.

## ✨ المميزات الرئيسية

### للمرضى والعملاء
- 🔍 **كتالوج أدوية شامل** مع بحث متقدم وفلترة حسب الفئة والسعر
- 💊 **صفحات تفاصيل مفصلة** لكل دواء (الاستخدام، الجرعة، التحذيرات، التفاعلات)
- 🛒 **سلة تسوق ذكية** مع إدارة الكميات وحساب الإجمالي
- 📋 **نظام الطلبات** مع تتبع حالة الطلب في الوقت الفعلي
- 📸 **رفع الوصفات الطبية** مع معالجة الصور
- 💬 **روبوت محادثة AI** للإجابة على الاستفسارات الصيدلانية
- 🌍 **واجهة عربية كاملة** مع دعم RTL

### للصيدلانيين والمديرين
- 📊 **لوحة تحكم متقدمة** لإدارة الطلبات والوصفات
- ✅ **إدارة حالات الطلبات** (قيد المراجعة، موافق، جاهز، مكتمل)
- 📦 **إدارة المخزون** والأدوية المتاحة
- 👥 **نظام أدوار وصلاحيات** (مريض، صيدلاني، مدير)

## 🏗️ البنية التكنولوجية

### Frontend
- **React 19** - مكتبة واجهات المستخدم
- **Tailwind CSS 4** - تصميم استجابي وحديث
- **TypeScript** - أمان النوع والموثوقية
- **Wouter** - التوجيه والملاحة
- **shadcn/ui** - مكونات واجهة احترافية

### Backend
- **Express.js 4** - خادم الويب
- **tRPC 11** - اتصال آمن من النهاية إلى النهاية
- **Drizzle ORM** - إدارة قاعدة البيانات
- **MySQL/TiDB** - قاعدة البيانات

### المصادقة والأمان
- **Manus OAuth** - مصادقة آمنة وموثوقة
- **JWT** - توقيع الجلسات
- **HTTPS** - تشفير البيانات

## 🚀 البدء السريع

### المتطلبات
- Node.js 18+
- pnpm (مدير الحزم)
- MySQL أو TiDB

### التثبيت

```bash
# استنساخ المستودع
git clone https://github.com/asemalthery99-bit/My-pharmacy-.git
cd My-pharmacy-

# تثبيت الاعتماديات
pnpm install

# إعداد متغيرات البيئة
cp .env.example .env.local

# تشغيل خادم التطوير
pnpm dev
```

### البناء والنشر

```bash
# بناء المشروع
pnpm build

# اختبار البناء محلياً
pnpm start

# نشر على Vercel
vercel deploy
```

## 📁 هيكل المشروع

```
my-pharmacy-app/
├── client/                 # تطبيق React
│   ├── src/
│   │   ├── pages/         # صفحات التطبيق
│   │   ├── components/    # مكونات معاد استخدامها
│   │   ├── contexts/      # سياقات React
│   │   ├── hooks/         # hooks مخصصة
│   │   ├── lib/           # مكتبات مساعدة
│   │   └── App.tsx        # المكون الرئيسي
│   └── public/            # ملفات ثابتة
├── server/                # خادم Express
│   ├── routers.ts         # تعريفات tRPC
│   ├── db.ts              # دوال قاعدة البيانات
│   └── _core/             # ملفات البنية الأساسية
├── drizzle/               # تعريفات قاعدة البيانات
│   └── schema.ts          # جداول قاعدة البيانات
├── shared/                # كود مشترك
├── vite.config.ts         # تكوين Vite
├── tsconfig.json          # تكوين TypeScript
├── package.json           # الاعتماديات
└── vercel.json            # تكوين Vercel
```

## 🗄️ قاعدة البيانات

### الجداول الرئيسية

- **users** - بيانات المستخدمين والمصادقة
- **medicines** - كتالوج الأدوية
- **categories** - فئات الأدوية
- **cart_items** - عناصر سلة التسوق
- **orders** - الطلبات
- **order_items** - تفاصيل الطلبات
- **prescriptions** - الوصفات الطبية
- **reviews** - التقييمات والمراجعات

## 🔐 الأمان

- ✅ مصادقة OAuth آمنة
- ✅ تشفير البيانات الحساسة
- ✅ التحقق من الصلاحيات على كل طلب
- ✅ حماية من CSRF و XSS
- ✅ معايير OWASP

## 📝 API الرئيسية

### الأدوية
- `GET /api/trpc/medicines.list` - قائمة الأدوية
- `GET /api/trpc/medicines.detail` - تفاصيل دواء
- `GET /api/trpc/medicines.categories` - الفئات

### السلة والطلبات
- `GET /api/trpc/cart.list` - عناصر السلة
- `POST /api/trpc/cart.add` - إضافة للسلة
- `POST /api/trpc/orders.create` - إنشاء طلب
- `GET /api/trpc/orders.list` - قائمة الطلبات

### الوصفات والمحادثة
- `POST /api/trpc/prescriptions.upload` - رفع وصفة
- `POST /api/trpc/chatbot.ask` - سؤال الروبوت

## 🧪 الاختبار

```bash
# تشغيل الاختبارات
pnpm test

# الاختبارات مع التغطية
pnpm test:coverage
```

## 📦 النشر على Vercel

### الخطوات

1. **ربط المستودع**
   ```bash
   vercel link
   ```

2. **إعداد متغيرات البيئة**
   - أضف `DATABASE_URL`
   - أضف `JWT_SECRET`
   - أضف متغيرات OAuth

3. **النشر**
   ```bash
   vercel deploy --prod
   ```

### متطلبات Vercel
- ✅ Node.js 18+
- ✅ Build command: `pnpm build`
- ✅ Output directory: `dist`
- ✅ Install command: `pnpm install`

## 🌐 متغيرات البيئة المطلوبة

```env
# قاعدة البيانات
DATABASE_URL=mysql://user:password@host:port/database

# المصادقة
JWT_SECRET=your-secret-key
VITE_APP_ID=your-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://oauth.manus.im

# API
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=your-api-key
VITE_FRONTEND_FORGE_API_KEY=your-frontend-key
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im

# المالك
OWNER_NAME=Your Name
OWNER_OPEN_ID=your-open-id

# التحليلات
VITE_ANALYTICS_ENDPOINT=https://analytics.manus.im
VITE_ANALYTICS_WEBSITE_ID=your-website-id
```

## 🤝 المساهمة

نرحب بالمساهمات! يرجى:

1. Fork المستودع
2. إنشاء فرع للميزة (`git checkout -b feature/amazing-feature`)
3. Commit التغييرات (`git commit -m 'Add amazing feature'`)
4. Push للفرع (`git push origin feature/amazing-feature`)
5. فتح Pull Request

## 📄 الترخيص

هذا المشروع مرخص تحت MIT License - انظر ملف LICENSE للتفاصيل.

## 📞 الدعم

للمساعدة والدعم:
- 📧 البريد الإلكتروني: support@ibpharmacy.com
- 💬 Discord: [رابط الخادم]
- 🐛 الإبلاغ عن الأخطاء: [Issues]

## 🙏 شكر خاص

شكر خاص لـ:
- فريق Manus على منصة التطوير
- مجتمع React و TypeScript
- جميع المساهمين والمستخدمين

---

**تم التطوير بـ ❤️ من قبل فريق IBPharmacy**

آخر تحديث: مارس 2026
